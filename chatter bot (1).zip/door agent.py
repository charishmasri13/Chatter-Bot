import random
import time
class DoorAgent:
    def __init__(self):
        self.door_state="CLOSED"

    def detect_motion(self):
        return random.choice([True,False])
    
    def open_door(self):
        print("   opening door......")
        self.door_state="OPEN"
        time.sleep(2)

    def close_door(self):
        print("  closing door......")
        self.door_state="CLOSED"
        time.sleep(2)
    
    def run(self):
        print("  Automatic door system started")
        print("press ctrl+c to stop the program")

        try:
            while True:
                motion_detected=self.detect_motion()

                if motion_detected:
                    print("\n  Motion detected!")
                    if self.door_state=="CLOSED":
                        self.open_door()
                    else:
                        print("\nNo motion detected")
                        if self.door_state=="OPEN":
                            self.close_door()
                    time.sleep(1)
        except KeyboardInterrupt:
            print("\n Automatic door system stopped")

if __name__=="__main__":
    door_agent=DoorAgent()
    door_agent.run()
